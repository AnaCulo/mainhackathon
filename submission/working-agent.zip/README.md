# Group Culo working agent

Source revision 5cb1f963bfe9667ce98d1ef21fc33f7932048d14. See backend/README.md for the governed Python backend and n8n/README.md for the workflow demo. Run the live chain (backend -> hosted BRANE -> n8n -> handler) with n8n/demo.sh --trace; the voice harness with n8n/demo.sh --voice; the ElevenLabs agent setup and end-to-end call are in voice/README.md. Current hand-in CSVs are under submission/ and traces are under evidence/.
