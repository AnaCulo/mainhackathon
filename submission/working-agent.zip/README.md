# Group Culo working agent

Source revision a56785910cb0234e4a95dbe845c0ff186ddf5069. See backend/README.md for the governed Python backend and n8n/README.md for the workflow demo. Run the live chain (backend -> hosted BRANE -> n8n -> handler) with n8n/demo.sh --trace; the voice harness with n8n/demo.sh --voice; the ElevenLabs agent setup and end-to-end call are in voice/README.md. Current hand-in CSVs are under submission/ and traces are under evidence/.
