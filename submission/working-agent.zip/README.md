# Group Culo working agent

Source revision 29353d0e9654d333e644b2e153cb87822dbf478c. See backend/README.md for the governed Python backend and n8n/README.md for the workflow demo. Run the live chain (backend -> hosted BRANE -> n8n -> handler) with n8n/demo.sh --trace; the voice harness with n8n/demo.sh --voice. Current hand-in CSVs are under submission/ and traces are under evidence/.
