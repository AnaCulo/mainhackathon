# Group Culo working agent

Source revision fae34b9534f29dac8ebd62c397fa582301703278. See backend/README.md for the governed Python backend and n8n/README.md for the workflow demo. The filmed Node demo is included. Current hand-in CSVs are under submission/ and traces are under evidence/.
