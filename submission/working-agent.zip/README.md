# Group Culo working agent

Source revision 4c1d7417d0f69adc68b89519933a0823bc05aecd. See backend/README.md for the governed Python backend, docs/website.md for the local demo website (http://127.0.0.1:8000/: typed or push-to-talk with local speech-to-text, live behind-the-scenes panel), and n8n/README.md for the workflow demo (n8n/demo.py). The ElevenLabs agent setup and end-to-end call are in voice/README.md. Current hand-in CSVs are under submission/ and traces are under evidence/.
