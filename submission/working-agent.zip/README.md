# Group Culo working agent

On Windows with Node 24 and npm, from this directory run .\n8n\demo.ps1 -Hold in PowerShell. See n8n/README.md and n8n/verification.md. The filmed Node backend and real workflow are included. Live gateway enforcement and employer deployment remain pending.
