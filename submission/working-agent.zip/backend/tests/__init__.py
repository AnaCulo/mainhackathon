"""Synthetic test fixtures only."""
